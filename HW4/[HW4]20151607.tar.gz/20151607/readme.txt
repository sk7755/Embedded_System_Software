COPYRIGHT : 20151607 Chung Jae Hoon
WRITEN BY : 20151607 Chung Jae Hoon

if you want to play puzzle game
press "Puzzle Game" button in main page.
then you insert "row col" in text editor and 
press "Make Buttons" button then row * col puzzle game start.
when start puzzle game, play time appears in upper screen.
if you complete puzzle game or quit the game, then play time disappears.
